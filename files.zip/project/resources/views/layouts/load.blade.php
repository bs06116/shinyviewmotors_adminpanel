@yield('styles')

@yield('content')

<script src="{{asset('assets/admin/js/load.js')}}"></script>
	
@yield('scripts')
